Unzip the file JPGSRCXX.zip in the ...\LIB\JPEG directory. The VISUALC++ 4.0 project jpg.mdp assumes all
JPEG library files are in that directory.  Do NOT delete or overwrite the file jconfig.h nor jmorecfg.h because it contains 
the right define switches to compile the JPEG library for the 32 bit Windows environment.

The source files has been modified by Dundas Software Ltd. in order to provide UNICODE support.