//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Test.rc
//
#define IDD_ABOUT                       102
#define IDD_POP3                        103
#define IDD_SMTP                        104
#define IDD_ATTACH_DLG                  105
#define IDI_ICON1                       106
#define IDC_APPENDLINE                  1000
#define IDC_BUTTON2                     1000
#define IDC_DISCONNECT                  1000
#define IDC_POP3                        1000
#define IDC_ADDLINE                     1001
#define IDC_BUTTON1                     1001
#define IDC_FINGER                      1001
#define IDC_SENDMAIL                    1001
#define IDC_CONNECT                     1001
#define IDC_ADD_BROWSE                  1001
#define IDC_DATESTAMP                   1002
#define IDC_BUTTON3                     1002
#define IDC_RETRIEVE                    1002
#define IDC_BROWSE                      1002
#define IDC_CLEAR                       1003
#define IDC_DELETE                      1003
#define IDC_EXIT                        1004
#define IDC_EDIT                        1005
#define IDC_SMTPSERVER                  1005
#define IDC_HISTORY                     1006
#define IDC_ALIGN                       1007
#define IDC_TEXTCOLOR                   1008
#define IDC_BACKCOLOR                   1009
#define IDC_BUTTON4                     1010
#define IDC_TOP                         1010
#define IDC_DEL                         1010
#define IDC_MESSAGE                     1011
#define IDC_FROM                        1012
#define IDC_SUBJECT                     1013
#define IDC_TO                          1014
#define IDC_CC                          1015
#define IDC_HOST                        1016
#define IDC_BCC                         1016
#define IDC_USER                        1017
#define IDC_FROM2                       1017
#define IDC_REPLYTO                     1017
#define IDC_PASS                        1018
#define IDC_NUMMSGS                     1019
#define IDC_MSGLIST                     1020
#define IDC_MSGNUM                      1021
#define IDC_STATUS                      1023
#define IDC_PROGRESS                    1025
#define IDC_STATUS2                     1027
#define IDC_COMBO1                      1030
#define IDC_ATTACH_ADD                  1031
#define ID_ADD                          1032
#define IDC_POP3_FROM                   1033
#define IDC_POP3_TO                     1034
#define IDC_POP3_SUBJECT                1035
#define IDC_POP3_CC                     1036
#define IDC_POP3_COMBO                  1038
#define IDC_SAVE_ATTACH                 1039
#define IDC_NUM_ATTACH                  1040
#define IDC_ABOUT                       1042
#define IDC_CHECKSSL                    1044
#define IDC_CHECKSECURITY               1044
#define IDC_CHECKTLS                    1045
#define IDC_EDITPORT                    1046
#define IDC_CHECKAUTH                   1047
#define IDC_EDIT2                       1048
#define IDC_EDITUSER                    1048
#define IDC_EDITPASS                    1049
#define IDC_CHECKPOPSEC                 1051
#define IDC_EDITPOPPORT                 1052
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
