// v4.2 update 01 - 64-bit 
#if defined(_WIN64)
// for UT_certwizard.cpp, UTCertifInstDlg.cpp, and UTCertifListDlg.cpp
#define GWL_USERDATA	GWLP_USERDATA
// for history control - uh_ctrl.cpp
#define GWL_HINSTANCE	GWLP_HINSTANCE
#endif